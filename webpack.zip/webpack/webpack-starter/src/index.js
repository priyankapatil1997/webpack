// DEMO JOKE APP
// import generateJoke from './generateJoke'
import "./styles/main.scss";
// import "./styles/issure.scss";
// import laughing from './assets/laughing.svg'

// const laughImg = documient.getElementById('laughImg')
// laughImg.src = laughing

// const jokeBtn = document.getElementById('jokeBtn')
// jokeBtn.addEventListener('click', generateJoke)

// generateJoke()
$(function () {
  if ($(".largest-issuers").length > 0) {
    // Method to put the data in sorted columns
    function generateIssuersTable(
      parentClassName,
      data,
      index,
      halfCount,
      type
    ) {
      const contentRow = document.createElement("div");
      contentRow.className = "largest-issuers__data";
      contentRow.setAttribute("role", "cell");

      const holdingsCellName = document.createElement("div");
      holdingsCellName.className = "largest-issuers__name";
      holdingsCellName.innerText = data.name;

      const holdingsCellValue = document.createElement("div");
      holdingsCellValue.className = "largest-issuers__percentage";
      holdingsCellValue.innerText = data.allocation;

      contentRow.append(holdingsCellName);
      contentRow.append(holdingsCellValue);

      if (type === "credit-issuers") {
        $(
          `${parentClassName} .largest-issuers__row .largest-issuers__content`
        ).append(contentRow);
      } else {
        if (index >= halfCount) {
          $(
            `${parentClassName} .largest-issuers__row .largest-issuers__content-left`
          ).append(contentRow);
        } else {
          $(
            `${parentClassName} .largest-issuers__row .largest-issuers__content-right`
          ).append(contentRow);
        }
      }
    }

    // Code to handle tabs in component
    $(".largest-issuers__tablist li").on("click", function () {
      $(this).addClass("active").siblings().removeClass("active");

      const activeTab = $(this).attr("data-tab");
      $(".largest-issuers__tabpanel").hide();
      $("#" + window.sanitize("string", activeTab)).show();
    });

    let contentObj = $(".largest-issuers").data("content");
    if (!contentObj) {
      return false;
    }

    // Strip the Script tag from data content if any
    contentObj = window.sanitize("json", contentObj);

    // Check if component have any disclosure to show
    contentObj = window.showDisclosure(contentObj, "largest-issuers");

    // Get active portfolio code
    const portfolioCode = window.getFundInfo()["portfolioCode"];
    const serviceURL =
      contentObj.services.funds_largest_issuers +
      `?portfoliocode=${portfolioCode}`;

    // Call the largest issuers API
    $.ajax({
      type: "GET",
      url: serviceURL,
      cache: true,

      success: function (response) {
        // Sanitize the API response
        response = window.sanitize("json", response);
        const timePeriod = window.convertToAsOfDate(
          response.asofdate,
          contentObj.subText,
          contentObj.dateFormat
        );

        $(".largest-issuers .largest-issuers__heading").html(
          contentObj.headerText
        );
        $(".largest-issuers .largest-issuers__period").html(
          window.sanitize("string", timePeriod)
        );

        // Get current portfolio data as per the active portfolio code
        const portfolioData = response.portfolios[portfolioCode];

        // Loop over the API response data to generate the issuers table
        if (contentObj.issuersType === "largest-issuers") {
          $(".largest-issuers__tabs")
            .find("li:first-child")
            .html(contentObj.tabOneText);
          $(".largest-issuers__tabs")
            .find("li:last-child")
            .html(contentObj.tabTwoText);

          const equityIssuers = portfolioData.equityIssuerTopHoldings;
          const creditIssuers = portfolioData.creditIssuerTopHoldings;
          const equityHalfCount = Math.ceil(equityIssuers.length / 2);
          const creditHalfCount = Math.ceil(creditIssuers.length / 2);

          equityIssuers.map(function (data, index) {
            generateIssuersTable(
              ".largest-issuers__equity-issuers",
              data,
              index,
              equityHalfCount,
              contentObj.issuersType
            );
          });

          creditIssuers.map(function (data, index) {
            generateIssuersTable(
              ".largest-issuers__credit-issuers",
              data,
              index,
              creditHalfCount,
              "credit-issuers"
            );
          });
        } else {
          $(".largest-issuers__tabs").hide();
          let topHoldingsData, topHoldingsHalfCount;
          if (contentObj.issuersType === "equity-issuers") {
            topHoldingsData = portfolioData.equityIssuerTopHoldings;
            topHoldingsHalfCount = Math.ceil(topHoldingsData.length / 2);
            topHoldingsData.map(function (data, index) {
              generateIssuersTable(
                ".largest-issuers__equity-issuer",
                data,
                index,
                topHoldingsHalfCount,
                contentObj.issuersType
              );
            });
          } else {
            topHoldingsData = portfolioData.creditIssuerTopHoldings;
            topHoldingsHalfCount = Math.ceil(topHoldingsData.length / 2);
            topHoldingsData.map(function (data, index) {
              generateIssuersTable(
                ".largest-issuers__credit-issuer",
                data,
                index,
                topHoldingsHalfCount,
                contentObj.issuersType
              );
            });
          }
        }

        // Calling getTippy method to instantiate the tippy for individual tooltip
        window.getTippy();
      },
    });
  }
});
