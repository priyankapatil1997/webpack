import { Counter } from './Counter'

export const App = () => {
  return (
    <>
      <h1>React TypeScript Webpack Starter Template</h1>
      <Counter />
    </>
  )
}
