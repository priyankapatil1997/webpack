import { useEffect, useState } from 'react'
import './styles/main.scss'
import data from './data.json'

export const Counter = () => {
  const [finalData, setFinalData] = useState([])

  useEffect(() => {
    setFinalData(data.portfolios[103].equityIssuerTopHoldings)
  }, [data])

  const switchTabs = (e, tab: string) => {
    if (tab === 'Equity Holdings') {
      setFinalData(data.portfolios[103].equityIssuerTopHoldings)
    }
    if (tab === 'Credits Holdings') {
      setFinalData(data.portfolios[103].creditIssuerTopHoldings)
    }
  }

  const divideData = Math.ceil(finalData.length / 2)

  return (
    <div className="App">
      <div
        className="largest-issuers aem-GridColumn aem-GridColumn--default--12"
        data-content='{"dateFormat": " MMMM d, yyyy", "type": "five", "headerText": "Ten largest holdings", "subText": "As of $date$ % of Fund", "tabOneText": "Equity Issuers", "tabTwoText": "Credit Issuers", "issuersType": "credit-issuers", "services": {"funds_largest_issuers": "https://dev-api.dodgeandcox.com/api/largest-issuer"}}'
      >
        <h2 className="largest-issuers__heading">Largest Issuer</h2>
        <div className="largest-issuers__period">March 21,2022</div>

        <div className="largest-issuers__tabs aem-GridColumn aem-GridColumn--default--12">
          <div
            className="largest-issuers__cmp-tabs"
            data-placeholder-text="false"
          >
            <ol
              role="tablist"
              className="largest-issuers__tablist"
              aria-multiselectable="false"
            >
              <li
                role="tab"
                className="largest-issuers__tab active"
                tabindex="0"
                aria-selected="true"
                data-tab="tabpanelOne"
                onClick={(e) => switchTabs(e, 'Equity Holdings')}
              >
                Equity Holdings
              </li>
              <li
                role="tab"
                className="largest-issuers__tab"
                tabindex="-1"
                aria-selected="false"
                data-tab="tabpanelTwo"
                onClick={(e) => switchTabs(e, 'Credits Holdings')}
              >
                Credits Holdings
              </li>
            </ol>
            <div
              className="largest-issuers__tabpanel largest-issuers__equity-issuers"
              id="tabpanelOne"
            >
              <div
                className="aem-Grid aem-Grid--12 aem-Grid--default--12"
                role="table"
              >
                <div
                  className="largest-issuers__row aem-GridColumn aem-GridColumn--default--10 aem-GridColumn--tablet--12 aem-GridColumn--phone--12 aem-GridColumn aem-GridColumn--offset--default--1 aem-GridColumn--offset--tablet--0 aem-GridColumn--offset--phone--0"
                  role="rowgroup"
                >
                  <div
                    className="largest-issuers__content-left aem-GridColumn aem-GridColumn--default--5 aem-GridColumn--tablet--6 aem-GridColumn--phone--12"
                    role="row"
                  >
                    {finalData.slice(-divideData).map((tableData) => {
                      return (
                        <div className="largest-issuers__data" role="cell">
                          <div className="largest-issuers__name">
                            {tableData.name}
                          </div>
                          <div className="largest-issuers__percentage">
                            {tableData.allocation}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                  <div
                    className="largest-issuers__content-right aem-GridColumn aem-GridColumn--default--5 aem-GridColumn--tablet--6 aem-GridColumn--phone--12"
                    role="row"
                  >
                    {finalData.slice(0, divideData).map((tableDataRight) => {
                      return (
                        <div className="largest-issuers__data" role="cell">
                          <div className="largest-issuers__name">
                            {tableDataRight.name}
                          </div>
                          <div className="largest-issuers__percentage">
                            {tableDataRight.allocation}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            </div>
            /*Credit Issuer*/
          </div>
        </div>

        <div className="largest-issuers__equity-issuer">
          <div className="aem-Grid aem-Grid--12" role="table">
            <div
              className="largest-issuers__row aem-GridColumn aem-GridColumn--default--10 aem-GridColumn--tablet--10 aem-GridColumn--phone--12 aem-GridColumn aem-GridColumn--offset--default--1 aem-GridColumn--offset--phone--0"
              role="rowgroup"
            >
              <div
                className="largest-issuers__content-left aem-GridColumn aem-GridColumn--default--5 aem-GridColumn--tablet--6 aem-GridColumn--phone--12"
                role="row"
              ></div>
              <div
                className="largest-issuers__content-right aem-GridColumn aem-GridColumn--default--5 aem-GridColumn--tablet--6 aem-GridColumn--phone--12"
                role="row"
              ></div>
            </div>
          </div>
        </div>
        <div className="largest-issuers__credit-issuer" role="table">
          <div className="aem-Grid aem-Grid--12">
            <div
              className="largest-issuers__row aem-GridColumn aem-GridColumn--default--12 aem-GridColumn--tablet--12 aem-GridColumn--phone--12"
              role="rowgroup"
            >
              <div
                className="largest-issuers__content aem-GridColumn aem-GridColumn--default--5 aem-GridColumn--tablet--6 aem-GridColumn--phone--12"
                role="row"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
