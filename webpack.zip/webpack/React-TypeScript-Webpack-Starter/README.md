## Download the starter kit

npx degit https://github.com/gopinav/React-TypeScript-Webpack-Starter my-app

## Install dependencies

cd my-app &&
yarn

## Run dev server

yarn start

## Build

yarn build
